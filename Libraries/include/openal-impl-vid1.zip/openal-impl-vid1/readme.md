# openal-impl

*A sample C++ implementation for a set of video tutorials*

[vid1](https://youtu.be/kWQM1iQ1W0E)